import React from "react";
import { ReportManagement } from "../Reporting";

export default function AdminReportManagement() {
  return <ReportManagement />;
}
