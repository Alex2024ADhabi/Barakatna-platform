// API configuration
export const API_BASE_URL =
  import.meta.env.VITE_API_URL || "https://api.barakatna.com/api/v1";
